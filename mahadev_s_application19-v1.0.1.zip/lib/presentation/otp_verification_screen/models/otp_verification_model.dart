class OtpVerificationModel {}
