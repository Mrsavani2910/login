class WelcomeModel {}
