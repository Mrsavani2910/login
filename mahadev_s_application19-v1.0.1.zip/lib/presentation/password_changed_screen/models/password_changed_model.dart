class PasswordChangedModel {}
