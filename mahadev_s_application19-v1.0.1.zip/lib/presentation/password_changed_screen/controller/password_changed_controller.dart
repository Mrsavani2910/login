import '/core/app_export.dart';
import 'package:mahadev_s_application19/presentation/password_changed_screen/models/password_changed_model.dart';

class PasswordChangedController extends GetxController {
  Rx<PasswordChangedModel> passwordChangedModelObj = PasswordChangedModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
