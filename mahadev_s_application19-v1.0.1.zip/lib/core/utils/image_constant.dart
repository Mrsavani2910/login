class ImageConstant {
  static String imgTimelight = 'assets/images/img_timelight.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgWifi = 'assets/images/img_wifi.svg';

  static String imgMobilesignal = 'assets/images/img_mobilesignal.svg';

  static String imgFacebook = 'assets/images/img_facebook.svg';

  static String imgFire = 'assets/images/img_fire.svg';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgGoogle = 'assets/images/img_google.svg';

  static String imgCombinedshape = 'assets/images/img_combinedshape.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
