import 'package:mahadev_s_application19/core/app_export.dart';

class ApiClient extends GetConnect {}
